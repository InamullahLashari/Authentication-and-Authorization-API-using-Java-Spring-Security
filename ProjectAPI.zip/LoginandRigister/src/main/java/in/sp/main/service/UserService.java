package in.sp.main.service;

import in.sp.main.entities.User;

public interface UserService 
{
public boolean RegisterUser(User user);//here object
public User loginUser(String email, String password);

}
