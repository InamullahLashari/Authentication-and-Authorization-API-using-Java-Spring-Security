package in.sp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginandRigisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginandRigisterApplication.class, args);
	}

}
