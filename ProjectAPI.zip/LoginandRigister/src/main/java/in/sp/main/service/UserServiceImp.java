package in.sp.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sp.main.entities.User;
import in.sp.main.repositories.UserRepository;


@Service
public class UserServiceImp implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public boolean RegisterUser(User user) {
		try {
			 userRepository.save(user);
				return true;
				
		} catch (Exception e) 
		{
			e.printStackTrace();
				return false;
				}
	}

	@Override
	public User loginUser(String email, String password) {
		User Validuser = userRepository.findByEmail(email);
		if(Validuser != null && Validuser.getPassword().equals(password))
			
		{
			return Validuser;
		}
		{
		
		return null;
	}
	
}}
