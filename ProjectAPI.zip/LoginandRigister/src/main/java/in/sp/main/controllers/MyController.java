package in.sp.main.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import in.sp.main.entities.User;
import in.sp.main.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class MyController {

    @Autowired
    private UserService userService;

    // Registration page
    @GetMapping("/regPage")
    public String OpenRegPage(Model model) {
        model.addAttribute("user", new User());
        return "registerpage"; // Returns the view (registerpage.html) with user object
    }

    @PostMapping("/regform") // URL mapping for registration form submission
    public String SubmitRegForm(@ModelAttribute("user") User user, Model model) {
        boolean status = userService.RegisterUser(user);
        if (status) {
            model.addAttribute("successMsg", "User registered successfully");
        } else {
            model.addAttribute("errorMsg", "User not registered due to some error");
        }
        return "registerpage"; // Return to the same registration page with a success/error message
    }

    // Login page
    @GetMapping("/logPage")
    public String OpenLogPage(Model model) {
        model.addAttribute("user", new User());
        return "loginpage"; // Returns the view (loginpage.html)
    }

    @PostMapping("/logform") // URL mapping for login form submission
    public String Submitlogform(@ModelAttribute("user") User user, Model model) {
        User validUser = userService.loginUser(user.getEmail(), user.getPassword());
        if (validUser != null) {
        	
        	model.addAttribute("modelName",validUser.getName());//this is ued for name
            return "profile"; // Navigate to the profile page on successful login
        } else { 
            model.addAttribute("errorMsg", "Invalid email or password");
            return "loginpage"; // Stay on the login page and show an error message
        }
    }
    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        // Invalidate session if it exists
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        // Redirect to the login page
        return "redirect:/logPage"; // Use the correct endpoint for your login page
    }

    
}
